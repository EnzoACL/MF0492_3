# ExpressBasics

1. Creamos un repo en GitHub
2. Clonamos en local con `git clone`
3. Abrimos la carpeta del proyecto con Studio Code `code carpeta_proyecto`
4. Iniciamos el proyecto de node:
```bash
npm init -y
npm install express
```
5. Creamos la carpeta `src` y nuestro `index.mjs`

Usa los ejemplos del repositorio y la codumentación [de Express](https://expressjs.com/es/starter/hello-world.html)